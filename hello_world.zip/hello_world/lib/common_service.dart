// import 'dart:convert';
// import 'package:http/http.dart' as http;
// import 'package:socket_io_client/socket_io_client.dart' as IO;

// class CommonService {
//   static final CommonService _instance = CommonService._internal();

//   factory CommonService() {
//     return _instance;
//   }

//   CommonService._internal();

//   IO.Socket? _socket;

//   final String _serviceHost = 'http://localhost:3000/';

//   IO.Socket get socket {
//     if (_socket == null) {
//       _socket = IO.io(_serviceHost, <String, dynamic>{
//         'transports': ['websocket', 'polling'],
//       });

//       _socket!.on('connect', (_) {
//         print('Connected to Socket.io server');
//       });

//       _socket!.on('connect_error', (error) {
//         print('Connection error: $error');
//       });

//       _socket!.on('disconnect', (_) {
//         print('Disconnected from Socket.io server');
//       });
//     }
//     return _socket!;
//   }

//   void listenForMessages(Function(dynamic) callback) {
//     socket.on('chatmessage', (message) => callback(message));
//   }

//   void sendMessage(String message) {
//     socket.emit('chatmessage', message);
//   }

//   Future<dynamic> getFunction(String url) async {
//     final response = await http.get(Uri.parse(_serviceHost + url));
//     if (response.statusCode == 200) {
//       return json.decode(response.body);
//     } else {
//       throw Exception('Failed to load data');
//     }
//   }

//   Future<dynamic> postFunction(String url, dynamic data) async {
//     final response = await http.post(
//       Uri.parse(_serviceHost + url),
//       headers: <String, String>{
//         'Content-Type': 'application/json; charset=UTF-8',
//       },
//       body: jsonEncode(data),
//     );
//     if (response.statusCode == 200) {
//       return json.decode(response.body);
//     } else {
//       throw Exception('Failed to post data');
//     }
//   }

//   Future<dynamic> putFunction(String url, String id, dynamic data) async {
//     final response = await http.put(
//       Uri.parse(_serviceHost + url + id),
//       headers: <String, String>{
//         'Content-Type': 'application/json; charset=UTF-8',
//       },
//       body: jsonEncode(data),
//     );
//     if (response.statusCode == 200) {
//       return json.decode(response.body);
//     } else {
//       throw Exception('Failed to update data');
//     }
//   }

//   Future<dynamic> deleteFunction(String url, dynamic data) async {
//     final response = await http.delete(
//       Uri.parse(_serviceHost + url + data),
//       headers: <String, String>{
//         'Content-Type': 'application/json; charset=UTF-8',
//       },
//     );
//     if (response.statusCode == 200) {
//       return json.decode(response.body);
//     } else {
//       throw Exception('Failed to delete data');
//     }
//   }
// }
